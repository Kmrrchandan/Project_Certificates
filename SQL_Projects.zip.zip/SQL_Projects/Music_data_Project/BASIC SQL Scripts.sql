#1. Who is the senior most employee based on job title?

SELECT * FROM employee
ORDER BY levels DESC
LIMIT 1

#2. Which countries have the most Invoices?

SELECT billing_country, COUNT(customer_id) AS "total_invoices" 
FROM invoice
GROUP BY billing_country
ORDER BY total_invoices DESC
LIMIT 1

#3. What are top 3 values of total invoice?

SELECT total FROM invoice
ORDER BY total DESC
LIMIT 3

#4. Which city has the best customers? 
We would like to throw a promotional Music Festival in the city 
we made the most money. Write a query that returns one city that 
has the highest sum of invoice totals. Return both the city name & sum of all invoice totals.

SELECT * FROM customer
SELECT * FROM invoice

SELECT city , SUM(I.total)total
FROM customer AS C
LEFT JOIN invoice AS I
ON C.customer_id=I.customer_id
GROUP BY City
ORDER BY total DESC
LIMIT 3


SELECT billing_city AS City , SUM(total) as invoice_total
FROM invoice
GROUP BY City
ORDER BY invoice_total DESC
LIMIT 3

#5. Who is the best customer? The customer who has spent the most 
money will be declared the best customer. Write a query that returns 
the person who has spent the most money.

SELECT * FROM invoice
SELECT * FROM customer

SELECT customer_id, sum	(total) AS sum
FROM invoice
GROUP BY customer_id
ORDER BY Sum DESC


SELECT C.customer_id, C.first_name, C.last_name , SUM(I.total) AS Total
FROM customer AS C
JOIN invoice AS I
on C.customer_id=I.customer_id
GROUP BY C.customer_id
ORDER BY Total DESC
LIMIT 3


































