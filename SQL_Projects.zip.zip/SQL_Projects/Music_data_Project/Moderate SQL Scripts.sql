#1. Write query to return the email, first name, last name, & Genre of all Rock Music listeners. 
Return your list ordered alphabetically by email starting with A


SELECT  DISTINCT C.email, C.first_name, C.last_name, R.name
FROM customer AS C
JOIN invoice AS I
ON C.customer_id=I.customer_id
JOIN Invoice_line AS N
ON I.invoice_id=N.invoice_id
JOIN track AS T
ON N.track_id=T.track_id
JOIN genre AS R
ON T.genre_id=R.genre_id
WHERE R.name='Rock'
ORDER BY C.email

#2.Let invite the artists who have written the most rock music in our dataset. 
Write a query that returns the Artist name and total track count of the top 10 rock bands.
SELECT * FROM artist"


SELECT R.artist_id, R.name, COUNT(R.artist_id) AS number_of_songs
FROM track AS T
JOIN album AS A
ON A.album_id=T.album_id
JOIN artist AS R
ON R.artist_id=A.artist_id
JOIN genre AS G
ON T.genre_id=G.genre_id
WHERE G.name ='Rock'
GROUP BY R.artist_id
ORDER BY number_of_songs DESC
LIMIT 10;


#3. Return all the track names that have a song length longer than the average song length. 
Return the Name and Milliseconds for each track. 
Order by the song length with the longest songs listed first

SELECT * FROM customer
SELECT * FROM genre
SELECT * FROM track
SELECT * FROM invoice_line
SELECT * FROM invoice
SELECT * FROM artist
SELECT * FROM album

SELECT name, milliseconds
FROM track
	WHERE 
		milliseconds>(SELECT ROUND(AVG(milliseconds),2)
					  	FROM track)
ORDER BY milliseconds DESC


































































































































